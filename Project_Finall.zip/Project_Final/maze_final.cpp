#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <string>
#include <algorithm>
#include <chrono>
using namespace std;
using namespace chrono;

// ===== Common Variables =====
int N, M;
vector<vector<int>> maze;
int dx[4] = {-1, 1, 0, 0};
int dy[4] = {0, 0, -1, 1};

// ===== Utility =====
bool isValid(int x, int y) {
    return (x >= 0 && x < N && y >= 0 && y < M && maze[x][y] == 0);
}

void printMaze(int startX, int startY, int endX, int endY) {
    cout << "\nMaze:\n\n";
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            if (i == startX && j == startY) cout << "A ";
            else if (i == endX && j == endY) cout << "B ";
            else if (maze[i][j] == 0) cout << ". ";
            else cout << "# ";
        }
        cout << endl;
    }
}

// ===== Backtracking =====
vector<vector<bool>> visited;
vector<pair<int,int>> path;
vector<vector<pair<int,int>>> allPaths;

bool isValidBT(int x, int y) {
    return (x >= 0 && x < N && y >= 0 && y < M && maze[x][y] == 0 && !visited[x][y]);
}

void backtrack(int x, int y, int endX, int endY) {
    if (x == endX && y == endY) {
        allPaths.push_back(path);
        return;
    }
    for (int i = 0; i < 4; i++) {
        int nx = x + dx[i];
        int ny = y + dy[i];
        if (isValidBT(nx, ny)) {
            visited[nx][ny] = true;
            path.push_back({nx, ny});
            backtrack(nx, ny, endX, endY);
            path.pop_back();
            visited[nx][ny] = false;
        }
    }
}

// ===== BFS =====
void saveHistory(const vector<pair<int,int>> &history,
                 const pair<int,int> &start,
                 const pair<int,int> &goal) {
    ofstream fout("history.txt");
    if (!fout) {
        cout << "Cannot create history.txt\n";
        return;
    }
    fout << "========== BFS MOVEMENT HISTORY ==========\n\n";
    for (int i = 0; i < history.size(); i++) {
        if (history[i] == start)
            fout << "(" << history[i].first << "," << history[i].second << ")   START\n";
        else if (history[i] == goal)
            fout << "(" << history[i].first << "," << history[i].second << ")   SUCCESS\n";
        else
            fout << "(" << history[i].first << "," << history[i].second << ")   VISIT\n";
    }
    fout << "\nVisited Nodes : " << history.size() << endl;
    fout.close();
}

bool bfs(int startX, int startY, int endX, int endY,
         vector<pair<int,int>> &path,
         vector<pair<int,int>> &bfsHistory,
         int &visitedCount) {
    vector<vector<bool>> vis(N, vector<bool>(M, false));
    vector<vector<pair<int,int>>> parent(N, vector<pair<int,int>>(M, {-1,-1}));
    queue<pair<int,int>> q;
    q.push({startX, startY});
    vis[startX][startY] = true;

    bool found = false;
    while (!q.empty()) {
        auto cur = q.front(); q.pop();
        bfsHistory.push_back(cur);
        int x = cur.first, y = cur.second;
        if (x == endX && y == endY) { found = true; break; }
        for (int i = 0; i < 4; i++) {
            int nx = x + dx[i], ny = y + dy[i];
            if (isValid(nx, ny) && !vis[nx][ny]) {
                vis[nx][ny] = true;
                parent[nx][ny] = {x, y};
                q.push({nx, ny});
            }
        }
    }
    if (!found) return false;

    int x = endX, y = endY;
    while (!(x == startX && y == startY)) {
        path.push_back({x, y});
        auto p = parent[x][y];
        x = p.first; y = p.second;
    }
    path.push_back({startX, startY});
    reverse(path.begin(), path.end());

    visitedCount = 0;
    for (int i = 0; i < N; i++)
        for (int j = 0; j < M; j++)
            if (vis[i][j]) visitedCount++;
    return true;
}

// ===== MAIN =====
int main() {
    string filename;
    cout << "Enter maze file name: ";
    cin >> filename;

    ifstream fin(filename);
    if (!fin) {
        cout << "Cannot open file " << filename << endl;
        return 1;
    }
    fin >> N >> M;
    maze.assign(N, vector<int>(M));
    for (int i = 0; i < N; i++)
        for (int j = 0; j < M; j++)
            fin >> maze[i][j];
    fin.close();

    int startX = 0, startY = 0, endX = N-1, endY = M-1;
    printMaze(startX, startY, endX, endY);

    cout << "\nChoose algorithm:\n1. Backtracking\n2. BFS\nYour choice: ";
    int choice; cin >> choice;

    auto begin = high_resolution_clock::now();

    if (choice == 1) {
        visited.assign(N, vector<bool>(M, false));
        visited[startX][startY] = true;
        path.push_back({startX, startY});
        backtrack(startX, startY, endX, endY);

        if (allPaths.empty()) cout << "\nNo path found!\n";
        else {
            cout << "\nTotal paths found: " << allPaths.size() << endl;
            int minLen = allPaths[0].size(), minIndex = 0;
            for (int i = 1; i < allPaths.size(); i++)
                if (allPaths[i].size() < minLen) { minLen = allPaths[i].size(); minIndex = i; }
            cout << "\nShortest path (length " << minLen << "): ";
            for (auto p : allPaths[minIndex]) cout << "(" << p.first << "," << p.second << ") ";
            cout << "-> END\n";
        }
    } else if (choice == 2) {
        vector<pair<int,int>> pathBFS;
        vector<pair<int,int>> bfsHistory;
        int visitedCount = 0;
        bool found = bfs(startX, startY, endX, endY, pathBFS, bfsHistory, visitedCount);
        if (!found) cout << "\nNo path found!\n";
        else {
            cout << "\nRobot moves through:\n\n";
            for (int i = 0; i < pathBFS.size(); i++) {
                cout << "(" << pathBFS[i].first << "," << pathBFS[i].second << ")";
                if (i != pathBFS.size()-1) cout << " -> ";
            }
            cout << " -> END\n";
            cout << "\nShortest path length: " << pathBFS.size()-1 << endl;
            cout << "Visited cells: " << visitedCount << endl;
            saveHistory(bfsHistory, {startX,startY}, {endX,endY});
            cout << "Movement history saved to history.txt\n";
        }
    } else cout << "Invalid choice!\n";

    auto finish = high_resolution_clock::now();
    double runtime = duration<double, milli>(finish - begin).count();
    cout << "Running time: " << runtime << " ms\n";

    return 0;
}
