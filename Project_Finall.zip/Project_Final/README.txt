1. Nội dung dự án
- Chương trình giải mê cung bằng 2 thuật toán:
- Backtracking: tìm tất cả đường đi, chọn đường ngắn nhất.
- BFS (Breadth-First Search): tìm đường đi ngắn nhất, lưu lịch sử duyệt vào `history.txt`.
- Các file mê cung mẫu: `maze_easy.txt`, `maze_hard.txt`, `maze_deadend.txt`, `maze.txt`.
2. Cách compile
Mở PowerShell/Terminal trong thư mục `Project_Final` và gõ:
g++ maze_final.cpp -o maze.exe
3. Cách chạy
./maze.exe
4. Nhập dữ liệu
- Khi chương trình hỏi:
  Enter maze file name:
  → Nhập tên file mê cung, ví dụ: `maze.txt`.
- Sau đó chương trình hỏi:
  Choose algorithm:
  1. Backtracking
  2. BFS
  Your choice:
  → Nhập `1` để chạy Backtracking, hoặc `2` để chạy BFS.
5. Kết quả
- Backtracking:
  - In tất cả đường đi tìm được.
  - Chọn và in đường ngắn nhất.
  - Hiển thị thời gian chạy.
- BFS:
  - In đường đi ngắn nhất.
  - Hiển thị số ô đã duyệt.
  - Hiển thị thời gian chạy.
  - Tự động tạo file `history.txt` ghi lại toàn bộ quá trình duyệt.
 6. File `history.txt`
- Được tạo khi chạy BFS.
- Nội dung gồm:
  - `START`: điểm bắt đầu.
  - `VISIT`: các ô BFS duyệt qua.
  - `SUCCESS`: điểm đích.
  - Tổng số ô đã duyệt.